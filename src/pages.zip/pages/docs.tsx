const DocsPage = () => {
  return (
    <div>
      <p>This is umi docs.</p>
    </div>
  );
};

export default DocsPage;
